# 资产测绘

```
fofa:icon_hash="-908445132"
```

# 使用方法

```
-h 查看帮助信息
-u 指定单个url测试
-f 指定多个url批量测试（文件内存储多个url）
eg:python test.py -u http://yourip+yourport
   python test.py -f url.txt
```

# 结果

```
结果全部保存在result.txt文件内
```

